# Issue Tracking System

The Issue app of the ITS project is the Issue Tracking System app 

The system  provides two types of users viz. Customer and Maintenance Staff 

  Admin panel has to be used to add a new user 
   Customer is default type of user ,decided by user_type attribute 
   for  user_type = 0 the user is customer and user_type=1 user is Maintenance staff
  
  In the Home page of the Cutomer there is list of issues that the customer has submitted 
  with an option to remove a issue from the list once resolved.
  The customer also can add new issues
  
  In the home page of the maintenance staff there is a list of issues in the most recent first fashion.
  
