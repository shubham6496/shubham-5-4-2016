from django.apps import AppConfig


class IssueConfig(AppConfig):
    name = 'Issue'
